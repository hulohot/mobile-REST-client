package com.csce4623.ahnelson.restclientexample;

import android.app.Activity;
import android.content.Context;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.IOException;
import java.util.Collections;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class UserService implements Callback<User> {

    private UserAPI userApi;
    private Gson gson;
    private Retrofit retrofit;
    private Activity activity;

    static final String BASE_URL = "https://jsonplaceholder.typicode.com/";

    UserService() {
        gson = new GsonBuilder()
                .setLenient()
                .create();

        retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();
        userApi = retrofit.create(UserAPI.class);
    }

    void getUserByUserId(int userId, Activity activity) throws IOException {
        activity = (MainActivity) activity;

        Call<User> call = userApi
                .loadUserByUserId(userId);
        call.enqueue(this);
    }


    @Override
    public void onResponse(Call<User> call, Response<User> response) {
        if(response.isSuccessful()) {
            User user = response.body();
        }
    }

    @Override
    public void onFailure(Call<User> call, Throwable t) {

    }
}
